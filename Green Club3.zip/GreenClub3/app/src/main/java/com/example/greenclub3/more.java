package com.example.greenclub3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class more extends AppCompatActivity {

    ImageView backarrow;
    LinearLayout eplanning, echo, quiz,news,leaderboard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_more);

        backarrow = findViewById(R.id.backarrow);
        eplanning = findViewById(R.id.eplanning);
        echo = findViewById(R.id.echo);
        quiz = findViewById(R.id.quiz);
        news = findViewById(R.id.news);


        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(more.this,HomeActivity.class);
                startActivity(intent);
            }
        });

        eplanning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(more.this,eventcommitee.class);
                startActivity(intent);
            }
        });
        echo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(more.this,echochallanges.class);
                startActivity(intent);
            }
        });

        quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(more.this,quiz.class);
                startActivity(intent);
            }
        });
        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(more.this,ArticleListActivity.class);
                startActivity(intent);
            }
        });


    }

}


