package com.example.greenclub3;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {
    ImageView img1, img4, profile_icon,img3, cal;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    CardView shop;
    private static final int CAMERA_REQUEST = 100;
    private static final int CAMERA_PERMISSION_CODE = 101;
    private Uri imageUri;
    private String currentPhotoPath;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        img1 = findViewById(R.id.card1);
        img4 = findViewById(R.id.card4);
        shop = findViewById(R.id.card2);
        img3 = findViewById(R.id.img3);
        cal = findViewById(R.id.calender);
        ImageView cameraIcon = findViewById(R.id.camera);
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        //side navigation bar
        profile_icon = findViewById(R.id.icon_profile);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);

        cal.setOnClickListener(v -> {
            // Get today's date
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    HomeActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        Toast.makeText(getApplicationContext(), "Selected Date: " + selectedDate, Toast.LENGTH_SHORT).show();
                    },
                    year, month, day);

            datePickerDialog.show();
        });

        // Request camera permission before opening the camera
        cameraIcon.setOnClickListener(v -> requestCameraPermission());

        // BottomNavigationView Click Listener
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_gallary) {
                Intent intent = new Intent(HomeActivity.this, GalleryActivity.class);
                startActivity(intent);
                return true;
            } else if (item.getItemId() == R.id.navigation_community) {
                Intent intent = new Intent(HomeActivity.this, CommunityChatActivity.class);
                startActivity(intent);
                return true;

            }
            else if (item.getItemId() == R.id.navigation_notification) {
                Intent intent = new Intent(HomeActivity.this, NotificationActivity.class);
                startActivity(intent);
                return true;

            }
            return false;
        });

        // Button Click Listeners
        Button scanTreeButton = findViewById(R.id.btn_open_tree_scan);
        scanTreeButton.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, TreeScanActivity.class);
            startActivity(intent);
        });

        img1.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, eventss.class);
            startActivity(intent);
        });

        img4.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, more.class);
            startActivity(intent);
        });

        shop.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, shop.class);
            startActivity(intent);
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, defender.class);
                startActivity(intent);
            }
        });

        profile_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.nav_profile) {
                    Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                    startActivity(intent);
                } else if (id == R.id.nav_settings) {
                    Intent intent = new Intent(HomeActivity.this, SettingsActivity.class);
                    startActivity(intent);
                } else if (id == R.id.nav_logout) {
                    Intent intent = new Intent(HomeActivity.this, LogoutActivity.class);
                    startActivity(intent);
                } else if (id == R.id.nav_about) {
                    Intent intent = new Intent(HomeActivity.this, AboutActivity.class);
                    startActivity(intent);
                }else if (id == R.id.nav_share) {
                    Intent intent = new Intent(HomeActivity.this, ShareAppActivity.class);
                    startActivity(intent);
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        // Open Database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.openDatabase();
    }
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    // Request Camera Permission
    private void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        } else {
            openCamera(); // If permission is already granted
        }
    }

    // Handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Camera permission is required!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Open Camera
    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();
            if (photoFile != null) {
                imageUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photoFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(this, "Error creating image file!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No camera app found!", Toast.LENGTH_SHORT).show();
        }
    }

    // Create image file
    private File createImageFile() {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String imageFileName = "GreenClub_" + timeStamp + ".jpg";
            File storageDir;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Use app's private storage on Android 10+
                storageDir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GreenClubGallery");
            } else {
                // Use external storage for older versions
                storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "GreenClubGallery");
            }

            if (!storageDir.exists() && !storageDir.mkdirs()) {
                return null; // Return null if directory creation fails
            }

            File image = new File(storageDir, imageFileName);
            currentPhotoPath = image.getAbsolutePath();
            return image;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Handle camera result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Toast.makeText(this, "Image saved to Green Club Gallery!", Toast.LENGTH_SHORT).show();

            // Refresh gallery (Android 10+ requires alternative methods)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, imageUri));
            } else {
                Toast.makeText(this, "Gallery refresh not required on Android 10+", Toast.LENGTH_SHORT).show();
            }

        } else {

        }
    }
}
