package com.example.greenclub3;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.location.Address;
import android.location.Geocoder;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class ReportActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 105;
    private String latitude, longitude;
    private Bitmap receivedImage;
    private ImageView reportImage;
    private TextView locationText;
    private EditText issueDescription;
    private Button reportButton;
    private Spinner authoritySpinner;

    // Mapping authorities to their contacts
    private final Map<String, String> authorityContacts = new HashMap<>();
    private final Map<String, String> authorityEmails = new HashMap<>();

    private String fullAddress = "Address not available";  // Default text if fetching fails

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        reportImage = findViewById(R.id.reportImage);
        locationText = findViewById(R.id.locationText);
        issueDescription = findViewById(R.id.issueDescription);
        reportButton = findViewById(R.id.reportButton);
        authoritySpinner = findViewById(R.id.authoritySpinner);

        // Populate authority contacts
        authorityContacts.put("Municipal Environmental Inspector", "9960401686");
        authorityContacts.put("Campus Infrastructure Coordinator", "9960401686");
        authorityContacts.put("Laboratory Technician", "8806672569");

        // Populate authority emails
        authorityEmails.put("Municipal Environmental Inspector", "kumbharprarthana05@gmail.com");
        authorityEmails.put("Campus Infrastructure Coordinator", "kumbharprarthana05@gmail.com");
        authorityEmails.put("Laboratory Technician", "kumbharprarthana05@gmail.com");

        // Spinner Adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, authorityContacts.keySet().toArray(new String[0]));
        authoritySpinner.setAdapter(adapter);

        // Receive data from MainActivity
        Intent intent = getIntent();
        latitude = intent.getStringExtra("latitude");
        longitude = intent.getStringExtra("longitude");
        byte[] byteArray = intent.getByteArrayExtra("image");

        if (byteArray != null) {
            receivedImage = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            reportImage.setImageBitmap(receivedImage);
        }

        // Convert lat/lng to actual address
        if (latitude != null && longitude != null) {
            fullAddress = getAddressFromLatLng(Double.parseDouble(latitude), Double.parseDouble(longitude));
            locationText.setText(fullAddress);  // Show the actual address in UI
        }

        reportButton.setOnClickListener(v -> showReportOptions());

        // Request SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // 📌 Convert lat/lng into a readable address
    private String getAddressFromLatLng(double lat, double lng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            if (!addresses.isEmpty()) {
                Address address = addresses.get(0);
                return address.getAddressLine(0);  // Return full address
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Unable to fetch address";  // If Geocoder fails
    }

    // 📌 Show Report Options in Alert Dialog
    private void showReportOptions() {
        String selectedAuthority = authoritySpinner.getSelectedItem().toString();
        String phoneNumber = authorityContacts.get(selectedAuthority);
        String emailAddress = authorityEmails.get(selectedAuthority);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Reporting Method");

        String[] options = {"📞 Call", "📩 Send SMS", "📧 Send Email"};
        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0:
                    makePhoneCall(phoneNumber);
                    break;
                case 1:
                    sendSMSReport(phoneNumber);
                    break;
                case 2:
                    sendEmailReport(emailAddress);
                    break;
            }
        });

        builder.create().show();
    }

    // 📞 Phone Call Function
    private void makePhoneCall(String phoneNumber) {
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(callIntent);
    }


    private void sendSMSReport(String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            return;
        }

        String issueText = issueDescription.getText().toString().trim();
        if (issueText.isEmpty()) {
            Toast.makeText(this, "Enter issue details before sending SMS!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Upload image first (This part requires Firebase or ImageKit integration)
        String imageUrl = "https://your-storage-service.com/uploaded-image.jpg"; // Replace with actual uploaded image URL

        // Google Maps link with lat/lng
        String mapsLink = "https://www.google.com/maps/search/?api=1&query=" + latitude + "," + longitude;

        String smsMessage = "⚠ Environmental Issue Report ⚠\n" +
                "📍 Location: " + fullAddress + "\n" +
                "📝 Issue: " + issueText + "\n" +
                "📌 View Location: " + mapsLink + "\n" +
                "🖼 Image: " + imageUrl;  // Include image URL

        try {
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> messageParts = smsManager.divideMessage(smsMessage);
            smsManager.sendMultipartTextMessage(phoneNumber, null, messageParts, null, null);

            Toast.makeText(this, "SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Failed! " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }



    // 📧 Send Email Report with Image & Location
    private void sendEmailReport(String emailAddress) {
        String issueText = issueDescription.getText().toString().trim();

        if (issueText.isEmpty()) {
            Toast.makeText(this, "Enter issue details before sending Email!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Google Maps link with lat/lng
        String mapsLink = "https://www.google.com/maps/search/?api=1&query=" + latitude + "," + longitude;

        // Email content
        String emailSubject = "⚠ Environmental Issue Report";
        String emailBody = "📍 *Location:* " + fullAddress + "\n\n" +
                "📝 *Issue:* " + issueText + "\n\n" +
                "📌 *View Location on Map:* " + mapsLink + "\n\n" +
                "📷 *Image Attached Below*";

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822"); // Email format
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailAddress});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, emailSubject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, emailBody);

        // Attach Image (if available)
        if (receivedImage != null) {
            String imagePath = MediaStore.Images.Media.insertImage(getContentResolver(), receivedImage, "Issue Image", null);
            Uri imageUri = Uri.parse(imagePath);
            emailIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
            emailIntent.setType("image/*");  // Allow image attachment
        }

        try {
            startActivity(Intent.createChooser(emailIntent, "Send Email"));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "No Email Clients Installed!", Toast.LENGTH_SHORT).show();
        }
    }

}