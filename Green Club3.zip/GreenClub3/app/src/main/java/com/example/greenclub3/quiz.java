package com.example.greenclub3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class quiz extends AppCompatActivity {

    private TextView questionText, resultText, questionNumber;
    private RadioButton option1, option2, option3, option4;
    private Button nextButton, previousButton;
    private RadioGroup optionsGroup;
    private ImageView resultBoard;
    private List<QuizQuestion> questionList;
    private int currentQuestionIndex = 0, score = 0;
    private boolean isQuizCompleted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        questionNumber = findViewById(R.id.questionNumber);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        nextButton = findViewById(R.id.nextButton);
        previousButton = findViewById(R.id.previousButton);
        optionsGroup = findViewById(R.id.optionsGroup);
        resultBoard = findViewById(R.id.resultBoard);

        resultBoard.setVisibility(View.GONE);
        resultText.setVisibility(View.GONE);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        questionList = dbHelper.getAllQuestions();

        if (questionList == null || questionList.isEmpty()) {
            Toast.makeText(this, "No questions found!", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        loadQuestion();

        nextButton.setOnClickListener(view -> {
            if (!isQuizCompleted) {
                checkAnswer();
                if (currentQuestionIndex < questionList.size() - 1) {
                    currentQuestionIndex++;
                    loadQuestion();
                } else {
                    showResult();
                }
            }
        });

        previousButton.setOnClickListener(view -> {
            if (!isQuizCompleted && currentQuestionIndex > 0) {
                currentQuestionIndex--;
                loadQuestion();
            }
        });
    }

    private void loadQuestion() {
        if (isQuizCompleted) return;

        QuizQuestion question = questionList.get(currentQuestionIndex);
        questionText.setText(question.getQuestion());
        option1.setText(question.getOption1());
        option2.setText(question.getOption2());
        option3.setText(question.getOption3());
        option4.setText(question.getOption4());
        optionsGroup.clearCheck();

        questionNumber.setText("Question " + (currentQuestionIndex + 1) + " of " + questionList.size());
    }

    private void checkAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedOption = findViewById(selectedId);
            if (selectedOption.getText().toString().equals(questionList.get(currentQuestionIndex).getAnswer())) {
                score++;
            }
        }
    }

    private void showResult() {
        isQuizCompleted = true;
        questionText.setVisibility(View.GONE);
        optionsGroup.setVisibility(View.GONE);
        nextButton.setVisibility(View.GONE);
        previousButton.setVisibility(View.GONE);

        resultBoard.setVisibility(View.VISIBLE);
        resultText.setVisibility(View.VISIBLE);
        resultText.setText("Your Score is: " + score + "/" + questionList.size());
    }
}
