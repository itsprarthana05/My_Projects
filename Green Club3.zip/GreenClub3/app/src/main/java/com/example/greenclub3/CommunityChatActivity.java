package com.example.greenclub3;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CommunityChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText edtMessage;
    private Button btnSend;
    private ChatAdapter chatAdapter;
    private List<MessageModel> messageList;

    private DatabaseReference chatRef;
    private FirebaseUser currentUser;
    private String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_chat);

        recyclerView = findViewById(R.id.recyclerViewChat);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        messageList = new ArrayList<>();

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        currentUserId = currentUser != null ? currentUser.getUid() : "";

        chatRef = FirebaseDatabase.getInstance().getReference("CommunityChat"); // ✅ chatRef initialized before adapter
        chatAdapter = new ChatAdapter(this, messageList, currentUserId, chatRef);
        recyclerView.setAdapter(chatAdapter);

        loadChatMessages();

        btnSend.setOnClickListener(v -> sendMessage());
    }

    private void sendMessage() {
        String message = edtMessage.getText().toString().trim();
        if (TextUtils.isEmpty(message)) return;

        if (currentUser != null) {
            String senderId = currentUser.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(senderId);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String senderName = snapshot.child("name").getValue(String.class);
                    if (senderName == null) senderName = "Unknown";

                    long timestamp = System.currentTimeMillis();
                    String messageId = chatRef.push().getKey();

                    if (messageId != null) {
                        MessageModel newMessage = new MessageModel(messageId, senderId, senderName, message, timestamp);
                        chatRef.child(messageId).setValue(newMessage).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) edtMessage.setText("");
                            else Toast.makeText(CommunityChatActivity.this, "Failed to send message!", Toast.LENGTH_SHORT).show();
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(CommunityChatActivity.this, "Failed to fetch user data!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    private void loadChatMessages() {
        chatRef.orderByChild("timestamp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messageList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    MessageModel message = dataSnapshot.getValue(MessageModel.class);
                    if (message != null) messageList.add(message);
                }
                chatAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(messageList.size() - 1); // auto scroll to bottom
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CommunityChatActivity.this, "Failed to load chat!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
