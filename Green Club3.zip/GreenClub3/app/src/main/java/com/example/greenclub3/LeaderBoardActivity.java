package com.example.greenclub3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;;

public class LeaderBoardActivity extends AppCompatActivity {
    LinearLayout event1, event2, event3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader_board);
        event1 = findViewById(R.id.treeplantation);
        event2 = findViewById(R.id.ewaste);
        event3 = findViewById(R.id.cleanUp);

        event1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LeaderBoardActivity.this, TreePlantationEvent.class);
                startActivity(intent);
            }
        });

        event2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LeaderBoardActivity.this, EWasteEvent.class);
                startActivity(intent);
            }
        });

        event3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LeaderBoardActivity.this, CleanUpEvent.class);
                startActivity(intent);
            }
        });






    }
}