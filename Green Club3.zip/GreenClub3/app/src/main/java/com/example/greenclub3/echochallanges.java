package com.example.greenclub3;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class echochallanges extends AppCompatActivity
{
    private RecyclerView recyclerChallenges;
    private ChallengeAdapter adapter;
    private List<ChallengeModel> challengeList;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_echochallanges);

        recyclerChallenges = findViewById(R.id.recyclerChallenges);
        recyclerChallenges.setLayoutManager(new LinearLayoutManager(this));

        loadChallenges();
    }
    private void loadChallenges()
    {
        challengeList = new ArrayList<>();
        challengeList.add(new ChallengeModel(1, "Plant a Tree", "Plant a tree in your locality", 40));
        challengeList.add(new ChallengeModel(2, "Water Plants", "Water a plant daily for a week", 70));
        challengeList.add(new ChallengeModel(3, "Reduce Plastic", "Use cloth bags instead of plastic", 30));

        adapter = new ChallengeAdapter(this, challengeList, position ->
        {
            ChallengeModel challenge = challengeList.get(position);
            challenge.setProgress(challenge.getProgress() + 10);
            adapter.notifyItemChanged(position);
        });
        recyclerChallenges.setAdapter(adapter);
    }
}
