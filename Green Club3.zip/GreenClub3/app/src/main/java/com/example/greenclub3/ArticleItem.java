package com.example.greenclub3;

public class ArticleItem {
    private int id;
    private String title, description, imageUrl, date, newsUrl;

    public ArticleItem(int id, String title, String description, String imageUrl, String date, String newsUrl) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.imageUrl = imageUrl;
        this.date = date;
        this.newsUrl = newsUrl; // ✅ News URL added
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getImageUrl() { return imageUrl; }
    public String getDate() { return date; }
    public String getNewsUrl() { return newsUrl; } // ✅ Getter for News URL
}
