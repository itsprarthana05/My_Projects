package com.example.greenclub3;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface PlantNetApiService {
    @Multipart
    @POST("v2/identify/all")
    Call<PlantIdentificationResponse> identifyPlant(
            @Part MultipartBody.Part image,
            @Query("api-key") String apiKey
    );
}
