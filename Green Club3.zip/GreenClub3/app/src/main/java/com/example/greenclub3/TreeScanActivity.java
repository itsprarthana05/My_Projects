package com.example.greenclub3;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TreeScanActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST_CODE = 100;
    private ImageView imageView;
    private TextView plantDetailsTextView;
    private Button scanButton, uploadButton;
    private File imageFile;

    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Bitmap photo = (Bitmap) result.getData().getExtras().get("data");
                            imageView.setImageBitmap(photo);
                            imageFile = saveImageToFile(photo);
                            if (imageFile != null) {
                                sendImageToPlantNet(imageFile);
                            }
                        }
                    });

    private final ActivityResultLauncher<Intent> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Uri selectedImageUri = result.getData().getData();
                            if (selectedImageUri != null) {
                                imageView.setImageURI(selectedImageUri);
                                imageFile = saveImageUriToFile(selectedImageUri);
                                if (imageFile != null) {
                                    sendImageToPlantNet(imageFile);
                                }
                            }
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tree_scan);

        imageView = findViewById(R.id.imageView);
        plantDetailsTextView = findViewById(R.id.tv_plant_details);
        scanButton = findViewById(R.id.btn_open_camera);
        uploadButton = findViewById(R.id.btn_upload_image);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST_CODE);
        }

        scanButton.setOnClickListener(v -> openCamera());
        uploadButton.setOnClickListener(v -> openGallery());
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            cameraLauncher.launch(cameraIntent);
        } else {
            Toast.makeText(this, "Camera not supported!", Toast.LENGTH_SHORT).show();
        }
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryIntent.setType("image/*");
        galleryLauncher.launch(galleryIntent);
    }

    private File saveImageToFile(Bitmap bitmap) {
        try {
            File file = new File(getCacheDir(), "tree_image.jpg");
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private File saveImageUriToFile(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            File file = new File(getCacheDir(), "tree_image.jpg");
            FileOutputStream fos = new FileOutputStream(file);
            if (inputStream != null) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
                inputStream.close();
            }
            fos.close();
            return file;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void sendImageToPlantNet(File imageFile) {
        RequestBody requestFile = RequestBody.create(imageFile, MediaType.parse("image/*"));
        MultipartBody.Part imagePart = MultipartBody.Part.createFormData("images", imageFile.getName(), requestFile);

        String apiKey = BuildConfig.PLANTNET_API_KEY;

        ApiClient.instance.identifyPlant(imagePart, apiKey).enqueue(new Callback<PlantIdentificationResponse>() {
            @Override
            public void onResponse(Call<PlantIdentificationResponse> call, Response<PlantIdentificationResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    String plantName = response.body().getBestMatch();
                    String scientificName = response.body().getScientificName();
                    String healthStatus = response.body().getHealthStatus();
                    String careInstructions = response.body().getCareInstructions();
                    String allCommonNames = response.body().getAllCommonNames();
                    String speciesDetails = response.body().getSpeciesDetails();

                    if (scientificName == null || scientificName.isEmpty()) scientificName = "Not Available";
                    if (healthStatus == null || healthStatus.isEmpty()) healthStatus = "Unknown";
                    if (careInstructions == null || careInstructions.isEmpty()) careInstructions = "No care instructions available.";
                    if (allCommonNames == null || allCommonNames.isEmpty()) allCommonNames = "No common names available.";

                    plantDetailsTextView.setTextColor(Color.BLACK);
                    plantDetailsTextView.setText(
                            "🌿 Plant Name: " + plantName +
                                    "\n🔬 Scientific Name: " + scientificName +
                                    "\n🪴 Common Names: " + allCommonNames +
                                    "\n🌱 Health Status: " + healthStatus +
                                    "\n📝 Care Instructions: " + careInstructions +
                                    "\n📋 Species Details: " + speciesDetails
                    );
                } else {
                    plantDetailsTextView.setText("No matching plant found❗ Please Try Again");
                    plantDetailsTextView.setTextColor(Color.RED);
                }
            }

            @Override
            public void onFailure(Call<PlantIdentificationResponse> call, Throwable t) {
                plantDetailsTextView.setText("Error: " + t.getMessage());
                plantDetailsTextView.setTextColor(Color.RED);
            }
        });
    }
}