package com.example.greenclub3;
public class NotificationItem {
    private String message;
    private String date;

    public NotificationItem() {
    }

    public NotificationItem(String message, String date) {
        this.message = message;
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public String getDate() {
        return date;
    }
}

