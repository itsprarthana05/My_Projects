package com.example.greenclub3;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class commitee2 extends AppCompatActivity {

    private DatabaseReference usersRef, eventsRef;
    private FirebaseUser currentUser;
    private String eventId = "E-Waste Collection Drive";  // **Event Name**

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commitee2);

        Button joinButton = findViewById(R.id.join_button);
        // Notification permission for Android 13+ (Tiramisu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
        }

        // Firebase setup
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        usersRef = FirebaseDatabase.getInstance().getReference("Users");
        eventsRef = FirebaseDatabase.getInstance().getReference("Event Planning Committee");

        joinButton.setOnClickListener(v -> {
            if (currentUser != null) {
                showCustomDialog();  // **Confirm Box दाखव**
            } else {
                Toast.makeText(this, "Please log in first!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Show Custom Dialog for Event Joining Confirmation
    private void showCustomDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_join_event);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        Button btnYes = dialog.findViewById(R.id.btn_yes);
        Button btnNo = dialog.findViewById(R.id.btn_no);

        btnYes.setOnClickListener(v -> {
            joinEvent(eventId);  // **User Event ला Join होईल**
            dialog.dismiss();
        });

        btnNo.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    // Join Event and Store User Info in Firebase
    private void joinEvent(String eventId) {
        String userId = currentUser.getUid(); // **User चा Unique ID**

        // Get user info from users node
        usersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class); // **Phone Number Fetch**

                    // Get current date (yyyy-MM-dd)
                    String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    // Create user data for event
                    HashMap<String, Object> userData = new HashMap<>();
                    userData.put("name", name);
                    userData.put("email", email);
                    userData.put("phone", phone);
                    userData.put("join_date", currentDate); // **Join Date Add**

                    // Store in event -> joined_users -> userId
                    eventsRef.child(eventId).child("joined_users").child(userId).setValue(userData)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(commitee2.this, "Event Joined Successfully!", Toast.LENGTH_SHORT).show();
                                String message = "Congratulations! 🎉\n" +
                                        "You have joined the event: " + eventId;

                                String formattedDate = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(new Date());

                                // Save notification locally (card view साठी)
                                NotificationItem item = new NotificationItem(message, formattedDate);
                                NotificationUtils.saveNotification(commitee2.this, item);

                                // ✅ Show local system notification (Heads-up)
                                NotificationUtils.showLocalNotification(commitee2.this, "Green Club", message);
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(commitee2.this, "Failed to join event!", Toast.LENGTH_SHORT).show();
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(commitee2.this, "Database error!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
