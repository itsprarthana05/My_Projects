package com.example.greenclub3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ChallengeAdapter extends RecyclerView.Adapter<ChallengeAdapter.ViewHolder> {

    private Context context;
    private List<ChallengeModel> challengeList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onChallengeClick(int position);
    }

    public ChallengeAdapter(Context context, List<ChallengeModel> challengeList, OnItemClickListener listener) {
        this.context = context;
        this.challengeList = challengeList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_challenge, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChallengeModel challenge = challengeList.get(position);
        holder.tvTitle.setText(challenge.getTitle());
        holder.tvDesc.setText(challenge.getDescription());
        holder.progressChallenge.setProgress(challenge.getProgress());

        if (challenge.getProgress() >= 100) {
            holder.tvStatus.setText("Completed");
            holder.tvStatus.setTextColor(context.getResources().getColor(android.R.color.holo_green_dark));
        } else {
            holder.tvStatus.setText("Pending");
            holder.tvStatus.setTextColor(context.getResources().getColor(android.R.color.holo_red_dark));
        }

        holder.itemView.setOnClickListener(v -> listener.onChallengeClick(position));
    }

    @Override
    public int getItemCount() {
        return challengeList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDesc, tvStatus;
        ProgressBar progressChallenge;
        ImageView imgChallenge;

        public ViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvChallengeTitle);
            tvDesc = itemView.findViewById(R.id.tvChallengeDesc);
            progressChallenge = itemView.findViewById(R.id.progressChallenge);
            tvStatus = itemView.findViewById(R.id.tvChallengeStatus);
            imgChallenge = itemView.findViewById(R.id.imgChallenge);
        }
    }
}
