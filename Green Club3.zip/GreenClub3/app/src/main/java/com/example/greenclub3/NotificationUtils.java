package com.example.greenclub3;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;

import java.util.List;

public class NotificationUtils {

    private static final String CHANNEL_ID = "greenclub_channel";

    public static void showLocalNotification(Context context, String title, String message) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Green Club Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Channel for Green Club notifications");
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.back_arrow) // या ठिकाणी तुमचा notification icon ठेवा
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    // ✅ हे method notification local storage मध्ये save करतं
    public static void saveNotification(Context context, NotificationItem item) {
        NotificationStorage.saveNotification(context, item);
    }

    // ✅ हे method notification list retrieve करतं
    public static List<NotificationItem> getNotifications(Context context) {
        return NotificationStorage.getNotifications(context);
    }
}
