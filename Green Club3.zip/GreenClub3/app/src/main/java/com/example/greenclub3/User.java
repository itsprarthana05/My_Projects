package com.example.greenclub3;

import com.google.firebase.database.PropertyName;

public class User {
    private String name, email, phone;

    @PropertyName("join_date") // Firebase key match
    private String joinDate;

    public User() {}

    public User(String name, String email, String phone, String joinDate) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.joinDate = joinDate;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }

    // ✅ फक्त Getter वर @PropertyName ठेवा
    @PropertyName("join_date")
    public String getJoinDate() { return joinDate; }
}
