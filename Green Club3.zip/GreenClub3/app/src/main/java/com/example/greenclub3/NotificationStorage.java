package com.example.greenclub3;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class NotificationStorage {

    private static final String PREFS_NAME = "notifications_pref";
    private static final String KEY_NOTIFICATIONS = "notification_list";

    public static void saveNotification(Context context, NotificationItem item) {
        List<NotificationItem> currentList = getNotifications(context);
        currentList.add(0, item); // latest notification top la
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_NOTIFICATIONS, new Gson().toJson(currentList)).apply();
    }

    public static List<NotificationItem> getNotifications(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_NOTIFICATIONS, null);

        if (json != null) {
            Type type = new TypeToken<List<NotificationItem>>() {}.getType();
            return new Gson().fromJson(json, type);
        }

        return new ArrayList<>();
    }
}
