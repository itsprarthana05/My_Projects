package com.example.greenclub3;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {

    private Context context;
    private List<MessageModel> messageList;
    private String currentUserId;
    private DatabaseReference chatRef;

    public ChatAdapter(Context context, List<MessageModel> messageList, String currentUserId, DatabaseReference chatRef) {
        this.context = context;
        this.messageList = messageList;
        this.currentUserId = currentUserId;
        this.chatRef = chatRef;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.chat_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MessageModel message = messageList.get(position);

        if (message != null) {
            String senderId = message.getSenderId();
            String senderName = message.getSenderName();
            String messageText = message.getMessage();

            // ✅ Show sender name and message text
            holder.senderName.setText(currentUserId.equals(senderId) ? "You" : senderName);
            holder.messageText.setText(messageText);

            // ✅ Allow delete only for user's own message
            if (currentUserId.equals(senderId)) {
                holder.itemView.setOnLongClickListener(v -> {
                    showDeleteDialog(message.getMessageId());
                    return true;
                });
            } else {
                holder.itemView.setOnLongClickListener(null);
            }
        }
    }

    private void showDeleteDialog(String messageId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Message");
        builder.setMessage("Are you sure you want to delete this message?");
        builder.setPositiveButton("Yes", (dialog, which) -> deleteMessage(messageId));
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void deleteMessage(String messageId) {
        if (chatRef != null && messageId != null) {
            chatRef.child(messageId).removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(context, "Message deleted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to delete message!", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return messageList != null ? messageList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView senderName, messageText;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            senderName = itemView.findViewById(R.id.senderName);
            messageText = itemView.findViewById(R.id.messageText);
        }
    }
}
