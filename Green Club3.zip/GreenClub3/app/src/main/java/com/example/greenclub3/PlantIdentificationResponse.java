package com.example.greenclub3;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PlantIdentificationResponse {

    @SerializedName("results")
    private List<Result> results;

    // Returns the best match for the common name of the plant
    public String getBestMatch() {
        return results != null && !results.isEmpty() &&
                results.get(0).species.commonNames != null &&
                !results.get(0).species.commonNames.isEmpty()
                ? results.get(0).species.commonNames.get(0)
                : "Unknown";
    }

    // Returns the scientific name of the plant
    public String getScientificName() {
        return results != null && !results.isEmpty()
                ? results.get(0).species.scientificName
                : "Not Available";
    }

    // Returns the health status of the plant
    public String getHealthStatus() {
        return results != null && !results.isEmpty()
                ? results.get(0).species.healthStatus
                : "Unknown";
    }

    // Returns care instructions for the plant
    public String getCareInstructions() {
        return results != null && !results.isEmpty()
                ? results.get(0).species.careInstructions
                : "No care instructions available.";
    }

    // Returns all common names of the species as a comma-separated string
    public String getAllCommonNames() {
        if (results != null && !results.isEmpty() &&
                results.get(0).species.commonNames != null) {
            return String.join(", ", results.get(0).species.commonNames);
        }
        return "No common names available.";
    }

    // Returns the species details including scientific and common names
    public String getSpeciesDetails() {
        String scientificName = getScientificName();
        String commonNames = getAllCommonNames();
        return "Scientific Name: " + scientificName + "\nCommon Names: " + commonNames;
    }

    public static class Result {
        @SerializedName("species")
        private Species species;
    }

    public static class Species {
        @SerializedName("scientificName")
        private String scientificName;

        @SerializedName("commonNames")
        private List<String> commonNames;

        @SerializedName("healthStatus")
        private String healthStatus;

        @SerializedName("careInstructions")
        private String careInstructions;
    }
}
