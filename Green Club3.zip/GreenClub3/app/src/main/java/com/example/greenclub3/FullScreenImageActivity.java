package com.example.greenclub3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.File;

public class FullScreenImageActivity extends AppCompatActivity {

    private ImageView fullScreenImage;
    private ImageView deleteFullImage;
    private String imagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen_image);

        fullScreenImage = findViewById(R.id.fullScreenImage);
        deleteFullImage = findViewById(R.id.deleteFullImage);

        // Get Image Path from Intent
        imagePath = getIntent().getStringExtra("imagePath");
        if (imagePath != null) {
            Glide.with(this).load(new File(imagePath)).into(fullScreenImage);
        }

        // Delete Image Functionality
        deleteFullImage.setOnClickListener(v -> confirmDeleteImage());
    }

    private void confirmDeleteImage() {
        // Alert Dialog for Confirmation
        new AlertDialog.Builder(this)
                .setTitle("Delete Image")
                .setMessage("Are you sure you want to delete this image?")
                .setPositiveButton("Yes", (dialog, which) -> deleteImage())
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteImage() {
        File file = new File(imagePath);
        if (file.exists() && file.delete()) {
            Toast.makeText(this, "Image deleted successfully!", Toast.LENGTH_SHORT).show();
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file))); // Update gallery
            finish(); // Close FullScreenActivity after deletion
        } else {
            Toast.makeText(this, "Failed to delete image!", Toast.LENGTH_SHORT).show();
        }
    }
}
