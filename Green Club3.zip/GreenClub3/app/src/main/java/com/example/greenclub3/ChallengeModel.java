package com.example.greenclub3;

public class ChallengeModel {
    private int id;
    private String title;
    private String description;
    private int progress;

    public ChallengeModel(int id, String title, String description, int progress) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.progress = progress;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }
}
