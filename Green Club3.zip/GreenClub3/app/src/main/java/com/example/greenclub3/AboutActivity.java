package com.example.greenclub3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Email Click Listeners
        setupEmailClick(R.id.txt_email1, "kudaveutkarsha07@gmail.com");
        setupEmailClick(R.id.txt_email2, "kumbharprarthana05@gmail.com");
        setupEmailClick(R.id.txt_email3, "schougale317@gmail.com");
    }

    private void setupEmailClick(int textViewId, final String email) {
        TextView emailTextView = findViewById(textViewId);
        emailTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:" + email));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Green Club App Inquiry");
                startActivity(emailIntent);
            }
        });
    }
}