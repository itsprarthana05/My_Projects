package com.example.greenclub3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;

public class EWasteEvent extends AppCompatActivity {
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;
    private DatabaseReference eventRef;
    ImageView img1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ewaste_event);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userList = new ArrayList<>();
        userAdapter = new UserAdapter(userList);
        recyclerView.setAdapter(userAdapter);
        img1 = findViewById(R.id.back_arrow);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EWasteEvent.this, LeaderBoardActivity.class);
                startActivity(intent);
            }
        });

        eventRef = FirebaseDatabase.getInstance().getReference("Event Planning Committee")
                .child("E-Waste Collection Drive").child("joined_users");

        fetchEventUsers();
    }

    private void fetchEventUsers() {
        eventRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot userSnap : snapshot.getChildren()) {
                        String name = userSnap.child("name").getValue(String.class);
                        String email = userSnap.child("email").getValue(String.class);
                        String phone = userSnap.child("phone").getValue(String.class);
                        String joinDate = userSnap.child("join_date").getValue(String.class); // 🔥 Fix here!

                        userList.add(new User(name, email, phone, joinDate));
                    }
                    userAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(EWasteEvent.this, "No users joined yet!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(EWasteEvent.this, "Failed to load data!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
