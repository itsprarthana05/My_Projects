package com.example.greenclub3;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

public class defender extends AppCompatActivity {

    private static final int IMAGE_CAPTURE_CODE = 103;
    private static final int LOCATION_REQUEST_CODE = 102;
    private static final String REPORT_PHONE_NUMBER = "9960401686";

    private FusedLocationProviderClient fusedLocationClient;
    private TextView locationText;
    private ImageView capturedImage;
    private Button captureButton, viewMapButton, reportButton;
    private String latitude, longitude;
    private Bitmap capturedPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_defender);

        locationText = findViewById(R.id.locationText);
        capturedImage = findViewById(R.id.capturedImage);
        captureButton = findViewById(R.id.captureButton);
        viewMapButton = findViewById(R.id.viewMapButton);
        reportButton = findViewById(R.id.reportButton);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Check and request location permission
        checkLocationPermission();

        captureButton.setOnClickListener(v -> openCamera());
        viewMapButton.setOnClickListener(v -> openMap());
        reportButton.setOnClickListener(v -> openReportActivity());
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(cameraIntent, IMAGE_CAPTURE_CODE);
        } else {
            Toast.makeText(this, "No Camera App Found!", Toast.LENGTH_SHORT).show();
        }
    }

    private void getLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                latitude = String.valueOf(location.getLatitude());
                longitude = String.valueOf(location.getLongitude());

                // Convert lat/lng to address
                Geocoder geocoder = new Geocoder(this);
                try {
                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if (addresses != null && !addresses.isEmpty()) {
                        String address = addresses.get(0).getAddressLine(0);
                        locationText.setText("Location: " + address);
                    } else {
                        locationText.setText("Location: Lat " + latitude + ", Lng " + longitude);
                    }
                } catch (IOException e) {
                    locationText.setText("Location: Lat " + latitude + ", Lng " + longitude);
                }
            } else {
                Toast.makeText(this, "Failed to get location!", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void openMap() {
        if (latitude == null || longitude == null) {
            Toast.makeText(this, "Location not available!", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri gmmIntentUri = Uri.parse("geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude + "(Captured Location)&z=17");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Toast.makeText(this, "Google Maps not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void openReportActivity() {
        if (capturedPhoto == null || latitude == null || longitude == null) {
            Toast.makeText(this, "Capture image and get location first!", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, ReportActivity.class);
        intent.putExtra("latitude", latitude);
        intent.putExtra("longitude", longitude);

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        capturedPhoto.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        intent.putExtra("image", byteArray);

        startActivity(intent);
    }
    private void sendSMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            String message = "Environmental issue reported!\nLocation: https://maps.google.com/?q=" + latitude + "," + longitude;

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(REPORT_PHONE_NUMBER, null, message, null, null);
                Toast.makeText(this, "Report SMS sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SMS permission not granted!", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_REQUEST_CODE);
        } else {
            getLastLocation();  // If permission is already granted, get the location
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();  // Permission granted, get location
            } else {
                Toast.makeText(this, "Location permission denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMAGE_CAPTURE_CODE && resultCode == RESULT_OK) {
            capturedPhoto = (Bitmap) data.getExtras().get("data");
            capturedImage.setImageBitmap(capturedPhoto);
            getLastLocation();
        }
    }
}