package com.example.greenclub3;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MasterDB.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ARTICLES = "quiz_newsfeed";
    private static final String TABLE_QUIZ = "quiz_questions";
    private static final String TABLE_CHALLENGES = "challenges";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_IMAGE_URL = "imageUrl";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_NEWS_URL = "newsUrl";

    private static final String COLUMN_QUESTION = "question";
    private static final String COLUMN_OPTION1 = "option1";
    private static final String COLUMN_OPTION2 = "option2";
    private static final String COLUMN_OPTION3 = "option3";
    private static final String COLUMN_OPTION4 = "option4";
    private static final String COLUMN_ANSWER = "answer";

    private static final String COLUMN_CHALLENGE_ID = "id";
    private static final String COLUMN_CHALLENGE_TITLE = "title";
    private static final String COLUMN_CHALLENGE_DESCRIPTION = "description";
    private static final String COLUMN_CHALLENGE_PROGRESS = "progress";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CHALLENGES_TABLE = "CREATE TABLE " + TABLE_CHALLENGES + " (" +
                COLUMN_CHALLENGE_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_CHALLENGE_TITLE + " TEXT, " +
                COLUMN_CHALLENGE_DESCRIPTION + " TEXT, " +
                COLUMN_CHALLENGE_PROGRESS + " INTEGER)";
        db.execSQL(CREATE_CHALLENGES_TABLE);

        String CREATE_ARTICLES_TABLE = "CREATE TABLE " + TABLE_ARTICLES + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_IMAGE_URL + " TEXT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_NEWS_URL + " TEXT)";
        db.execSQL(CREATE_ARTICLES_TABLE);

        String CREATE_QUIZ_TABLE = "CREATE TABLE " + TABLE_QUIZ + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_QUESTION + " TEXT, " +
                COLUMN_OPTION1 + " TEXT, " +
                COLUMN_OPTION2 + " TEXT, " +
                COLUMN_OPTION3 + " TEXT, " +
                COLUMN_OPTION4 + " TEXT, " +
                COLUMN_ANSWER + " TEXT)";
        db.execSQL(CREATE_QUIZ_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ARTICLES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUIZ);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHALLENGES);
        onCreate(db);
    }

    public void addChallenge(ChallengeModel challenge) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CHALLENGE_ID, challenge.getId());
        values.put(COLUMN_CHALLENGE_TITLE, challenge.getTitle());
        values.put(COLUMN_CHALLENGE_DESCRIPTION, challenge.getDescription());
        values.put(COLUMN_CHALLENGE_PROGRESS, challenge.getProgress());
        db.insert(TABLE_CHALLENGES, null, values);
        db.close();
    }

    public void updateChallengeProgress(int id, int progress) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CHALLENGE_PROGRESS, progress);
        db.update(TABLE_CHALLENGES, values, COLUMN_CHALLENGE_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    public List<ChallengeModel> getAllChallenges() {
        List<ChallengeModel> challengeList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CHALLENGES, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String description = cursor.getString(2);
                int progress = cursor.getInt(3);
                challengeList.add(new ChallengeModel(id, title, description, progress));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return challengeList;
    }

    public void addArticle(String title, String description, String imageUrl, String date, String newsUrl) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_IMAGE_URL, imageUrl);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_NEWS_URL, newsUrl);
        db.insert(TABLE_ARTICLES, null, values);
        db.close();
    }

    public List<ArticleItem> getAllArticles() {
        List<ArticleItem> articles = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ARTICLES, null);

        if (cursor.moveToFirst()) {
            do {
                articles.add(new ArticleItem(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5)
                ));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return articles;
    }

    @SuppressLint("Range")
    public String getImageUrlFromDatabase(String newsUrl) {
        SQLiteDatabase db = this.getReadableDatabase();
        String imageUrl = "";
        Cursor cursor = db.query(TABLE_ARTICLES, new String[]{COLUMN_IMAGE_URL},
                COLUMN_NEWS_URL + " = ?", new String[]{newsUrl},
                null, null, null);

        if (cursor.moveToFirst()) {
            imageUrl = cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE_URL));
        }
        cursor.close();
        db.close();
        return imageUrl;
    }

    public List<QuizQuestion> getAllQuestions() {
        List<QuizQuestion> questionList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_QUIZ, null);

        if (cursor.moveToFirst()) {
            do {
                questionList.add(new QuizQuestion(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6)
                ));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return questionList;
    }

    public SQLiteDatabase openDatabase()
    {
        return this.getWritableDatabase();

    }
}
