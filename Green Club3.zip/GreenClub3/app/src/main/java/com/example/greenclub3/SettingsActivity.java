package com.example.greenclub3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    private LinearLayout helpSupport, themeChange;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check Theme Preference
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        boolean isDarkMode = sharedPreferences.getBoolean("DarkMode", false);
        if (isDarkMode) {
            setTheme(R.style.Theme_Dark);
        } else {
            setTheme(R.style.Theme_Light);
        }

        setContentView(R.layout.activity_settings);

        // Initialize UI Elements
        helpSupport = findViewById(R.id.helpSupport);

        // Help & Support Click
        helpSupport.setOnClickListener(v -> showEmailOptions());


    }

    // Help & Support Email Options
    private void showEmailOptions() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📩 Contact Us")
                .setItems(new String[]{"Email 1: kumbharprarthana05@gmail.com", "Email 2: kudaveutkarsha07@gmail.com", "Email 3: schougale317@gmail.com"},
                        (dialog, which) -> {
                            String email;
                            switch (which) {
                                case 0:
                                    email = "kumbharprarthana05@gmail.com";
                                    break;
                                case 1:
                                    email = "kudaveutkarsha07@gmail.com";
                                    break;
                                case 2:
                                    email = "schougale317@gmail.com";
                                    break;
                                default:
                                    email = "kumbharprarthana05@gmail.com";
                            }
                            sendEmail(email);
                        })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    // Email Intent
    private void sendEmail(String email) {
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:" + email));
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Help & Support Request");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Hello, I need help with...");
        startActivity(Intent.createChooser(emailIntent, "Send Email"));
    }


}
