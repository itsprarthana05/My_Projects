package com.example.greenclub3;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class eventcommitee extends AppCompatActivity {

    LinearLayout layout,layout2,layout3,layout4;
    ImageView back;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_eventcommitee);

        layout = findViewById(R.id.event1);
        layout2 = findViewById(R.id.event2);
        layout3 = findViewById(R.id.event3);
        layout4 = findViewById(R.id.leaderboard);
        back = findViewById(R.id.back_arrow_events);
        back.setOnClickListener(v -> {
            Intent intent = new Intent(this, more.class);
            startActivity(intent);
        });

        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(eventcommitee.this,commitee1.class);
                startActivity(intent);
            }
        });
        layout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(eventcommitee.this,commitee2.class);
                startActivity(intent);
            }
        });
        layout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(eventcommitee.this,commitee3.class);
                startActivity(intent);
            }
        });
        layout4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(eventcommitee.this, LeaderBoardActivity.class);
                startActivity(intent);
            }
        });
    }
}