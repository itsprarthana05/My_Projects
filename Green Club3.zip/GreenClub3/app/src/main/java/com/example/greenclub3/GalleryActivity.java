package com.example.greenclub3;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;

public class GalleryActivity extends AppCompatActivity {

    private GridView galleryGrid;
    private ArrayList<String> imagePaths;
    private GalleryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        galleryGrid = findViewById(R.id.galleryGrid);
        imagePaths = getImages();

        adapter = new GalleryAdapter(this, imagePaths);
        galleryGrid.setAdapter(adapter);

        // Click on an image to view in fullscreen
        galleryGrid.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(GalleryActivity.this, FullScreenImageActivity.class);
            intent.putExtra("imagePath", imagePaths.get(position));
            startActivity(intent);
        });

        // Long press to delete image
        galleryGrid.setOnItemLongClickListener((parent, view, position, id) -> {
            showDeleteConfirmation(position);
            return true;
        });
    }

    private ArrayList<String> getImages() {
        ArrayList<String> images = new ArrayList<>();
        File storageDir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GreenClubGallery");
        if (storageDir.exists() && storageDir.listFiles() != null) {
            for (File file : storageDir.listFiles()) {
                images.add(file.getAbsolutePath());
            }
        }
        return images;
    }

    private void showDeleteConfirmation(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Image")
                .setMessage("Are you sure you want to delete this image?")
                .setPositiveButton("Delete", (dialog, which) -> deleteImage(position))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteImage(int position) {
        File file = new File(imagePaths.get(position));
        if (file.exists() && file.delete()) {
            imagePaths.remove(position);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Image deleted!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete image!", Toast.LENGTH_SHORT).show();
        }
    }
}
