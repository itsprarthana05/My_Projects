package com.example.greenclub3;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class NewsDetailActivity extends AppCompatActivity {

    private TextView newsTitle, newsContent;
    private ImageView newsImage;
    private ProgressBar progressBar;
    private String newsUrl;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);

        // Initialize views
        newsTitle = findViewById(R.id.newsTitle);
        newsContent = findViewById(R.id.newsContent);
        newsImage = findViewById(R.id.newsImage);
        progressBar = findViewById(R.id.progressBar);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Get news URL from intent
        newsUrl = getIntent().getStringExtra("newsUrl");

        // If a news URL is available, start fetching the news content
        if (newsUrl != null) {
            // Show progress bar while loading
            progressBar.setVisibility(View.VISIBLE);
            new FetchNewsContent().execute(newsUrl);
        }
    }

    private class FetchNewsContent extends AsyncTask<String, Void, String[]> {

        @Override
        protected String[] doInBackground(String... urls) {
            try {
                // Fetch the title and content from the website
                Document doc = Jsoup.connect(urls[0]).get();

                // Extract the title of the news article
                String title = doc.title();

                // Extract paragraphs from the <article> tag or body tag
                Elements paragraphs = doc.select("article p");
                if (paragraphs.isEmpty()) {
                    paragraphs = doc.select("p"); // If <article> is missing, fetch all <p>
                }

                // Combine all paragraphs into a single string
                StringBuilder content = new StringBuilder();
                for (Element p : paragraphs) {
                    content.append(p.text()).append("\n\n");
                }

                // Fetch the image URL from the database
                String imageUrlFromDb = databaseHelper.getImageUrlFromDatabase(urls[0]);

                // Return the title, content, and image URL from the database
                return new String[]{title, content.toString().trim(), imageUrlFromDb};

            } catch (IOException e) {
                e.printStackTrace();
            }
            return new String[]{"Error fetching title.", "Error fetching news content.", ""};
        }

        @Override
        protected void onPostExecute(String[] result) {
            super.onPostExecute(result);

            // Hide progress bar when loading is complete
            progressBar.setVisibility(View.GONE);

            // Set the news title
            newsTitle.setText(result[0]);

            // Set the news content
            newsContent.setText(result[1]);

            // Load the image from the URL fetched from the database using Glide
            if (!result[2].isEmpty()) {
                // If image URL is available, load the image
                Glide.with(NewsDetailActivity.this)
                        .load(result[2]) // Image URL from the database
                        .diskCacheStrategy(DiskCacheStrategy.ALL) // Cache image for faster loading
                        .placeholder(R.drawable.placeholder) // Default image if loading
                        .error(R.drawable.error_image) // Error image if loading fails
                        .into(newsImage); // Set image to the ImageView
            } else {
                // If no image URL is found, use a placeholder or error image
                newsImage.setImageResource(R.drawable.error_image);
            }
        }
    }
}
